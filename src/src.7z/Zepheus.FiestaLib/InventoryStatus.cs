﻿
namespace Zepheus.FiestaLib
{
    public enum InventoryStatus : byte
    {
        ADDED,
        FULL,
        NOT_FOUND
    }
}
