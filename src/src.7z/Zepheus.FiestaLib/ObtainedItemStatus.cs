﻿
namespace Zepheus.FiestaLib
{
    public enum ObtainedItemStatus : ushort
    {
        OBTAINED = 0x0341,
        FAILED = 0x0342,
        INV_FULL = 0x0346,
    }
}
