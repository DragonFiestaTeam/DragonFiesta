﻿
namespace Zepheus.Util
{
    public class EntitySetting
    {
        public string DataSource { get; set; }
        public string DataCatalog { get; set; }
        public string Metadata { get; set; }

        public string Username { get; set; }
        public string Password { get; set; }
    }
}
