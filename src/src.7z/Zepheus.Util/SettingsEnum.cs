﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zepheus.Util
{
    public enum SettingsEnum
    {
        GameSettings,
        QuickBar,
        QuickBarState,
        Shortcuts,
    }
}
